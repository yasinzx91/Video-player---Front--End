import React, { useState } from 'react'
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import Form from 'react-bootstrap/Form';

function Category() {

  const [catogoryname, setCatagoryName] = useState("")

  const [show, setShow] = useState(false);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  const handleAddCatagory = async()=>{
    //func to add catagory
     if(catogoryname)
     {
        let body = {
          catogoryname,
          allVideos:[],
          
        }
     }
     else
     {
        alert('please fill the catagory name')
     }
  }


  return (
    <>
      <div className='d-grid ms-3'>
        <button className='btn btn-warning' onClick={handleShow}>Add New Category</button>
      </div>

      <Modal
        show={show}
        onHide={handleClose}
        backdrop="static"
        keyboard={false}
      >
        <Modal.Header closeButton>
          <Modal.Title>Add new Catagory</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <p>please fill the form completly</p>
          <Form action="" className='border border-secondary rounded p-3'>
            <Form.Group className="mb-3" controlId="formBasicEmail">
              <Form.Label>Catagory name</Form.Label>
              <Form.Control type="text" onChange={(e)=>setCatagoryName(e.target.value)} placeholder="Enter new catogory name"/>
            </Form.Group>
          </Form>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Close
          </Button>
          <Button variant="primary" onClick={handleAddCatagory}>Add</Button>
        </Modal.Footer>
      </Modal>
    </>
  )
}

export default Category