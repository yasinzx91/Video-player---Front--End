import { commonAPI } from "./commomAPI"
import { serverUrl } from "./serverUrl"

//upload videos


export const uploadAllVideos = async(reqBody)=>{
   return await commonAPI('POST',`${serverUrl}/videos`,reqBody)
}


export const getAllVideos = async()=>{
    return await commonAPI('GET',`${serverUrl}/videos`,'')
}

export const deleteVideo = async(id)=>{
    return await commonAPI('DELETE',`${serverUrl}/videos/${id}`,{})
}

export const addToHistory = async(videoDetails)=>{
    return await commonAPI('POST',`${serverUrl}/history`,videoDetails)
}


export const getAllHistory = async()=>{
    return await commonAPI('GET',`${serverUrl}/history`,"")
}


export const addToCatagory = async(body)=>{
    return await commonAPI('POST',`${serverUrl}/history`,body)
}


export const deleteHistory = async(id)=>{
    return await commonAPI('DELETE',`${serverUrl}/history/${id}`,{})
}